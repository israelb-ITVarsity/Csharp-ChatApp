using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace ChatApplication.Pages
{
    public class LoginFormModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        public ClientInfo Info = new ClientInfo();
        public String errorM = "";
        public String successM = "";

        public List<ClientInfo> ListClients = new List<ClientInfo>();

        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=Israel-Lenovo;Initial Catalog=ChatApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM Login;";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ClientInfo clientInfo = new ClientInfo();
                                clientInfo.Username = reader.GetString(1);
                                clientInfo.Email = reader.GetString(2);
                                clientInfo.Password = reader.GetString(3);

                                ListClients.Add(clientInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public void OnPost()
        {
            Info.Username = Request.Form["Username"];
            Info.Email = Request.Form["Email"];
            Info.Password = Request.Form["Password"];

            if (Info.Username.Length == 0 || Info.Email.Length == 0 || Info.Password.Length == 0)
            {
                errorM = "All fields are required";
                return;
            }

            // Check if the combination of username, email, and password exists in the database
            try
            {
                String connectionString = "Data Source=Israel-Lenovo;Initial Catalog=ChatApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    String sql = "SELECT Username, Email, Password FROM Login WHERE Username = @Username AND Email = @Email AND Password = @Password";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@Username", Info.Username);
                        command.Parameters.AddWithValue("@Email", Info.Email);
                        command.Parameters.AddWithValue("@Password", Info.Password);

                        // Execute the query to check if the combination exists
                        bool credentialsValid = command.ExecuteScalar() != null;

                        if (credentialsValid)
                        {
                            // Combination of username, email, and password is valid, show a success message
                            successM = "Successful Login!";
                            Response.Redirect("/WebApp");
                        }
                        else
                        {
                            // Combination does not exist in the database, prompt the user to sign up
                            errorM = "Invalid credentials. Please sign up.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorM = ex.Message;
            }
        }



    }
}

public class ClientInfo
{
    public String Username;
    public String Email;
    public String Password;
}