using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatApplication.Pages
{
    public class WebAppModel : PageModel
    {
        public void OnGet()
        {
        }

        public void OnPost() 
        { 
        
        }
    }
}
