using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace ChatApplication.Pages
{
    public class SignUpModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
        }

        public void OnPost()
        {
            clientInfo.Username = Request.Form["Username"];
            clientInfo.Email = Request.Form["Email"];
            clientInfo.Password = Request.Form["Password"];

            if (clientInfo.Username.Length == 0 || clientInfo.Email.Length == 0 || clientInfo.Password.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the new client into the database
            try
            {
                String connectionString = "Data Source=Israel-Lenovo;Initial Catalog=ChatApp;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    String sql = "INSERT INTO Login " + 
                                 "(Username, Email, Password) VALUES " + 
                                 "(@Username, @Email, @Password);";

                    using(SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@Username", clientInfo.Username);
                        command.Parameters.AddWithValue("@Email", clientInfo.Email);
                        command.Parameters.AddWithValue("@Password", clientInfo.Password);

                        command.ExecuteNonQuery();
                    }
                    
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            clientInfo.Username = ""; clientInfo.Email = ""; clientInfo.Password = "";
            successMessage = "New Client Added Correctly!";

            Response.Redirect("/LoginForm");
        }
    }
}
